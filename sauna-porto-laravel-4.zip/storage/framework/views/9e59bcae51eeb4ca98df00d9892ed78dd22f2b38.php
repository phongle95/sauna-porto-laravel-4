<?php /* C:\xampp\htdocs\shop-sauna\resources\views/admin/trangchu.blade.php */ ?>
<?php $__env->startSection('noidung'); ?>

<h2> hello admin</h2>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.menu.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>