 <?php $__env->startSection('noidung'); ?>
<main class="main">
    <br>
        <nav aria-label="breadcrumb" class="breadcrumb-nav">
            <div class="container">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html"><i class="icon-home"></i></a></li>
                    <li class="breadcrumb-item active" aria-current="page"><a href="">Tin Tức</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Chi Tiết</li>
                </ol>
            </div><!-- End .container -->
        </nav>

        <div class="container">
            <div class="row">
                <div class="col-lg-9">
                    <article class="entry single">
                        <div class="entry-media">
                            <div class="entry-slider owl-carousel owl-theme owl-theme-light">
                                <img src="upload/<?php echo e($chitiet->img); ?>" alt="máy xông hơi">

                            </div><!-- End .entry-slider -->
                        </div><!-- End .entry-media -->
                        <div class="fb-like" data-href="<?php echo e(route('trangchu.chitiet.news',['slug'=>str_slug($chitiet->tieuDe),'id'=>$chitiet->id,'ma'=>$chitiet->maLoaiTin])); ?>" data-layout="standard" data-action="like" data-size="small" data-show-faces="true" data-share="true"></div>
                        <br>  <br>
                        <div class="entry-body">
                            <div class="entry-date">
                                <span class="day"><?php echo e(date("d", strtotime($chitiet->date))); ?></span>
                                <span class="month">Jun</span>
                            </div><!-- End .entry-date -->

                            <h2 style="color:#0088cc" class="entry-title">
                                    <?php echo e($chitiet->tieuDe); ?>

                            </h2>

                            <div class="entry-meta">
                                <span><i class="icon-calendar"></i><?php echo e(date("d-m-Y", strtotime($chitiet->date))); ?></span>
                                <span><i class="icon-user"></i>By <a>Phong Lê</a></span>

                            </div><!-- End .entry-meta -->

                            <div class="entry-content">
                                    <?php echo $chitiet->noiDung; ?>

                            </div><!-- End .entry-content -->

                            <div class="entry-share">

                                </div><!-- End .entry-share -->
                                <div class="fb-comments" data-href="<?php echo e(route('trangchu.chitiet.news',['slug'=>str_slug($chitiet->tieuDe),'id'=>$chitiet->id,'ma'=>$chitiet->maLoaiTin])); ?>" data-numposts="5"></div>


                        </div><!-- End .entry-body -->
                    </article><!-- End .entry -->

                    <div class="related-posts">
                        <h4 class="light-title"><strong>Tin Liên Quan</strong></h4>

                        <div class="owl-carousel owl-theme related-posts-carousel">
                            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <article class="entry">
                                <div class="entry-media">
                                    <a href="<?php echo e(route('trangchu.chitiet.news',['slug'=>str_slug($item->tieuDe),'id'=>$item->id,'ma'=>$item->maLoaiTin])); ?>">
                                        <img style="height:160px;" src="upload/<?php echo e($item->img); ?>" alt="Máy Xông Hơi">
                                    </a>
                                </div><!-- End .entry-media -->

                                <div class="entry-body">
                                    <div class="entry-date">
                                        <span class="day"><?php echo e(date("d", strtotime($item->date))); ?></span>
                                        <span class="month">Jun</span>
                                    </div><!-- End .entry-date -->

                                    <h2 class="entry-title">
                                        <a href="<?php echo e(route('trangchu.chitiet.news',['slug'=>str_slug($item->tieuDe),'id'=>$item->id,'ma'=>$item->maLoaiTin])); ?>"><?php echo e($item->tieuDe); ?></a>
                                    </h2>

                                    <div class="entry-content">
                                        

                                        <a href="<?php echo e(route('trangchu.chitiet.news',['slug'=>str_slug($item->tieuDe),'id'=>$item->id,'ma'=>$item->maLoaiTin])); ?>" class="read-more">Đọc Thêm <i class="icon-angle-double-right"></i></a>
                                    </div><!-- End .entry-content -->
                                </div><!-- End .entry-body -->
                            </article>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div><!-- End .owl-carousel -->
                    </div><!-- End .related-posts -->
                </div><!-- End .col-lg-9 -->

                <aside class="sidebar col-lg-3">
                    <?php echo $__env->make('trangchu.menu.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </aside>
            </div><!-- End .row -->
        </div><!-- End .container -->

        <div class="mb-6"></div><!-- margin -->
    </main><!-- End .main -->
<!-- End .main -->
<?php $__env->stopSection(); ?> <?php $__env->startSection('meta'); ?>
<title><?php echo e($chitiet->tieuDe); ?></title>
<meta name="keywords" content="<?php echo e($chitiet->keyword); ?>" />
<meta name="description" content='<?php echo e($chitiet->tomTat); ?>' />
<!--meta facebook-->
<meta property="og:title" content="<?php echo e($chitiet->tieuDe); ?>" />
<meta property="og:description" content="<?php echo e($chitiet->tomTat); ?>" />
<meta property="og:image" content="upload/<?php echo e($chitiet->img); ?>" />
<!--meta google-->
<meta itemprop="name" content="Sauna Đà nẵng là một trong những công ty hàng đầu trong lĩnh vực thiết kế, lắp đặt , sửa chữa , bảo hành, cung ứng phòng , máy xông hơi tại Việt Nam.
Với đội ngũ nhân viên ngày càng đông đảo có trình độ chuyên môn cao, tay nghề vững vàng nên doanh nghiệp ngày càng được sự tín nhiệm của khách hàng." />
<meta itemprop="description" content="<?php echo e($chitiet->tomTat); ?>" />
<meta itemprop="image" content="upload/<?php echo e($chitiet->img); ?>" />
<meta name="og:url" content="<?php echo e(route('trangchu.chitiet.news',['slug'=>str_slug($chitiet->tieuDe),'id'=>$chitiet->id,'ma'=>$chitiet->maLoaiTin])); ?>" />
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('trangchu.menu.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sauna-mau-4\resources\views/trangchu/chitiet/news.blade.php ENDPATH**/ ?>