<?php /* C:\xampp\htdocs\shop-sauna\resources\views/admin/pages/loaitin/sua.blade.php */ ?>
<?php $__env->startSection('noidung'); ?>
<div class="row">
   <div class="col-md-12">
      <!-- DATA TABLE -->
      <div class="card">
         <div class="card-header">
            <strong>Sửa Loại Tin</strong>
         </div>
         <div class="card-body card-block">
            <form action="" method="POST" class="form-horizontal">
               <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
               <div class="row form-group">
                  <div class="col-12 col-md-12">
                     <label class="badge badge-info">Tên Loại Tin </label><br>
                     <input type="text" id="text-input" name="tenLoaiTin" value="<?php echo e($loaitin->tenLoaiTin); ?>" placeholder="Nhập tên loại tin" class="form-control">
                  </div>
               </div>
               <div class="card-footer">
                  <button type="submit" class="btn btn-success btn-fw">
                  Sửa
                  </button>
                  <a href="<?php echo e(route('admin.pages.loaitin.danhsach')); ?>" class="btn btn-info btn-fw">
                  Quay về
                  </a>
               </div>
            </form>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.menu.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>